const ALLOWED_SYMBOLS = new Set(['EUR/USD', 'GBP/USD', 'USD/JPY', 'XAU/USD']);
const ALLOWED_INTERVALS = new Set(['15min', '1h', '4h', '1day']);

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/api/health') {
      return json({ ok: true, service: 'TradeLab AI market-data proxy' });
    }
    if (url.pathname === '/api/market') {
      if (request.method !== 'GET') return json({ error: 'Method not allowed' }, 405);
      if (!env.TWELVE_DATA_API_KEY) return json({ error: 'Market-data API secret is not configured on this Worker.' }, 503);
      const symbol = (url.searchParams.get('symbol') || '').toUpperCase();
      const interval = url.searchParams.get('interval') || '15min';
      if (!ALLOWED_SYMBOLS.has(symbol)) return json({ error: `${symbol || 'Requested symbol'} is not enabled for the current Twelve Data integration. US30 is not included.` }, 422);
      if (!ALLOWED_INTERVALS.has(interval)) return json({ error: 'Unsupported interval.' }, 400);

      const cache = caches.default;
      const cacheKey = new Request(`${url.origin}/api/market?symbol=${encodeURIComponent(symbol)}&interval=${interval}`);
      const cached = await cache.match(cacheKey);
      if (cached) return cached;

      const providerUrl = new URL('https://api.twelvedata.com/time_series');
      providerUrl.searchParams.set('symbol', symbol);
      providerUrl.searchParams.set('interval', interval);
      providerUrl.searchParams.set('outputsize', '100');
      providerUrl.searchParams.set('apikey', env.TWELVE_DATA_API_KEY);
      const providerResponse = await fetch(providerUrl.toString(), { headers: { Accept: 'application/json' } });
      const payload = await providerResponse.json();
      if (!providerResponse.ok || payload.status === 'error' || !Array.isArray(payload.values) || payload.values.length < 2) {
        const message = payload.message || payload.code || 'The provider returned no usable candle data.';
        return json({ error: `Twelve Data: ${message}` }, providerResponse.status === 429 ? 429 : 502);
      }

      const chronological = payload.values.slice().reverse().map(candle => ({
        time: candle.datetime,
        value: Number(candle.close),
        open: Number(candle.open),
        high: Number(candle.high),
        low: Number(candle.low),
        close: Number(candle.close)
      })).filter(point => Number.isFinite(point.value));
      const first = chronological[0].value;
      const latest = chronological[chronological.length - 1];
      const changePercent = first ? ((latest.value - first) / first) * 100 : 0;
      const result = json({
        source: 'Twelve Data', symbol, interval,
        quote: { symbol, price: latest.value, changePercent, datetime: latest.time },
        values: chronological
      }, 200, { 'Cache-Control': 'public, max-age=30' });
      await cache.put(cacheKey, result.clone());
      return result;
    }
    if (env.ASSETS) return env.ASSETS.fetch(request);
    return new Response('Not found', { status: 404 });
  }
};

function json(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...extraHeaders }
  });
}
