exports.handler = async () => ({
  statusCode: 200,
  headers: { 'content-type': 'application/json' },
  body: JSON.stringify({ service: 'tradelab-ai', status: 'ok', mode: 'demo', liveExecution: false })
});
