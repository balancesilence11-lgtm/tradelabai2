# TradeLab AI — trading analysis platform foundation

Responsive React/Vite frontend for a personal trading workspace.

## Phase 2 update
- Added US30 to the instrument watchlist.
- Added working 15m, 1H, 4H and 1D chart timeframe controls.
- Added an optional 8-period moving-average overlay.
- Updated chart generation to adapt to the selected instrument and timeframe.
- Corrected the stylesheet import so Vite resolves `src/style.css`.

## Current implementation
- Responsive dashboard and navigation
- Overview, market watch, AI analysis preview, trading ticket preview, trade history, risk controls, broker connections, admin and settings screens
- Clearly labelled illustrative market prices and simulated chart history
- Manual / assisted / automated mode preference UI
- Risk preference slider (UI only; not enforced)
- Deriv and MetaTrader 5 connection placeholders

## Important limitations
This remains a **frontend prototype**, not a live trading system. Market prices and chart history are simulated/illustrative. There is no live market-data provider, AI-generated signal service, real authentication, user database, broker authorisation, MT5 connectivity, server-side risk enforcement or order execution. The trading ticket does not submit orders. Do not use the displayed figures to make financial decisions.

## Run locally
Requires Node.js 20+.

```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```

## Deployment
The existing Cloudflare Workers deployment can continue to use the built `dist` directory. Keep API keys and broker credentials out of browser code and source control.

## Production architecture still required
1. Authentication with verified email, password reset and role-based access.
2. PostgreSQL database with row-level tenant isolation.
3. Server-side API and a licensed market-data provider.
4. Official Deriv authorisation with scoped per-user tokens stored encrypted.
5. MT5 integration through a separately hosted, secured bridge or broker-approved connector.
6. Server-side pre-trade risk checks, idempotency, audit log and emergency kill switch.
7. Demo/paper testing, security review and explicit account-owner consent before any live execution.

Never commit `.env` files, broker passwords, API tokens or other secrets to GitHub. Keep live execution disabled until all production controls have been independently tested.
